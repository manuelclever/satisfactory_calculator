// Copyright Coffee Stain Studios. All Rights Reserved.

#pragma once

#include "FGInventoryComponent.h"
#include "Resources/FGItemDescriptor.h"
#include "FGInventoryLibrary.h"

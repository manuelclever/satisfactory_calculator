// Copyright Coffee Stain Studios. All Rights Reserved.

#pragma once


static const uint8 BUILDABLE_COLORS_MAX_SLOTS = 18;


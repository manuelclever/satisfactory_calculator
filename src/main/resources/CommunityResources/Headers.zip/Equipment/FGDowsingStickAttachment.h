// Copyright Coffee Stain Studios. All Rights Reserved.

#pragma once

#include "CoreMinimal.h"
#include "Equipment/FGEquipmentAttachment.h"
#include "FGDowsingStickAttachment.generated.h"

/**
 * 
 */
UCLASS()
class FACTORYGAME_API AFGDowsingStickAttachment : public AFGEquipmentAttachment
{
	GENERATED_BODY()
	
};

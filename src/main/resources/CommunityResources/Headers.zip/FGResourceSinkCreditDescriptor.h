// Copyright Coffee Stain Studios. All Rights Reserved.

#pragma once

#include "CoreMinimal.h"
#include "Resources/FGItemDescriptor.h"
#include "FGResourceSinkCreditDescriptor.generated.h"

/**
 * 
 */
UCLASS()
class FACTORYGAME_API UFGResourceSinkCreditDescriptor : public UFGItemDescriptor
{
	GENERATED_BODY()
	
};

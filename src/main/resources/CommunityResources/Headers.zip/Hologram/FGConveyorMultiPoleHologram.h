// Copyright Coffee Stain Studios. All Rights Reserved.

#pragma once

#include "CoreMinimal.h"
#include "Hologram/FGBuildableHologram.h"
#include "FGConveyorMultiPoleHologram.generated.h"

/**
 * 
 */
UCLASS()
class FACTORYGAME_API AFGConveyorMultiPoleHologram : public AFGBuildableHologram
{
	GENERATED_BODY()
	
	
	
	
};
